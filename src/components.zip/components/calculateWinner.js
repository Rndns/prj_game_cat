// function calculateWinner(squares) {
//     const lines = [
//         [0, 1, 2],
//         [3, 4, 5],
//         [6, 7, 8],
//         [0, 3, 6],
//         [1, 4, 7],
//         [2, 5, 8],
//         [0, 4, 8],
//         [2, 4, 6],
//     ];
//     for (let i = 0; i < lines.length; i++) {
//         const [a, b, c] = lines[i];
//         if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
//         return squares[a];
//         }
//     }
//     return null;
// }


// export default calculateWinner;
// 보드 크기를 받아서 승리 조건을 생성하는 함수
function generateWinningLines(size) {
    const lines = [];

    // 가로 승리 조건 추가
    for (let row = 0; row < size; row++) {
        const horizontalLine = [];
        for (let col = 0; col < size; col++) {
            horizontalLine.push(row * size + col);
        }
        lines.push(horizontalLine);
    }

    // 세로 승리 조건 추가
    for (let col = 0; col < size; col++) {
        const verticalLine = [];
        for (let row = 0; row < size; row++) {
            verticalLine.push(row * size + col);
        }
        lines.push(verticalLine);
    }

    // 대각선 승리 조건 추가
    const diagonal1 = [];
    const diagonal2 = [];
    for (let i = 0; i < size; i++) {
        diagonal1.push(i * size + i);
        diagonal2.push(i * size + (size - 1 - i));
    }
    lines.push(diagonal1);
    lines.push(diagonal2);

    return lines;
}

// 승자를 계산하는 함수
function calculateWinner(squares, boardSize) {
    const lines = generateWinningLines(boardSize);
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const [a, b, c] = line;
        if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
            return squares[a];
        }
    }
    return null;
}

export default calculateWinner;
